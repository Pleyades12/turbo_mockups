import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { ArrowRight, Layers3, Clapperboard, Check, Sparkles, Clock, Palette } from "lucide-react"
import { CountdownTimer } from "@/components/countdown-timer"
import { FaqSchema } from "@/components/faq-schema"
import { StickyCTA } from "@/components/sticky-cta"
import { TestimonialsSection } from "@/components/testimonials-section"
import { AnimatedHeroImage } from "@/components/animated-hero-image"
import { MockupShowcase } from "@/components/mockup-showcase"

const faqData = [
  {
    question: "¿Qué necesito para usar TurboMockups?",
    answer:
      "Solo necesitas una cuenta en una plataforma de canva para aprovechar al maximo todas las funcionalidades de turbo mock ups",
  },
  {
    question: "¿Es un pago único o una suscripción?",
    answer:
      "Es un solo pago. Con tu compra obtienes acceso de por vida a la herramienta y a todas sus futuras actualizaciones, sin cargos recurrentes.",
  },
  {
    question: "¿Cómo recibo el acceso?",
    answer:
      "Inmediatamente después de completar tu compra, recibirás un correo electrónico con el enlace para acceder a la plantilla y a todos los video tutoriales.",
  },
  {
    question: "¿Con qué productos puedo trabajar?",
    answer:
      "Actualmente puedes trabajar con ropa (T-shirts, Sweatshirts, Hoodies), tazas (Mugs) y mantas (Blankets). ¡Y se seguirán agregando más productos!",
  },
  {
    question: "¿Puedo agregar mis propios mockups?",
    answer: "Así es, Turbo mockups está hecho para que puedas agregar tus propios mockups de forma ilimitada.",
  },
]

export default function TurboMockupsPage() {
  const launchDate = new Date()
  launchDate.setHours(launchDate.getHours() + 48)
  const checkoutUrl = "https://www.allisonramirezb.com/offers/krN7a4RB/checkout"

  return (
    <>
      <FaqSchema faqs={faqData} />
      <div className="flex flex-col min-h-dvh">
        {/* Header */}
        <header className="sticky top-0 z-50 w-full border-b border-primary/10 bg-background/80 backdrop-blur-lg">
          <div className="container flex h-16 items-center justify-between px-4 md:px-6">
            <div className="flex flex-col">
              <span className="font-serif text-xl sm:text-2xl font-bold tracking-wider text-primary">TurboMockups</span>
              <span className="text-xs sm:text-sm text-muted-foreground">by Allison Ramirez</span>
            </div>
            <a href={checkoutUrl} target="_blank" rel="noopener noreferrer" className="hidden sm:block">
              <Button className="bg-primary font-bold text-primary-foreground hover:bg-primary/90 transition-all duration-300">
                ¡Lo Quiero Ahora!
              </Button>
            </a>
          </div>
        </header>

        <main className="flex-1">
          {/* Hero Section */}
          <section className="w-full py-12 md:py-20 lg:py-28">
            <div className="container px-4 md:px-6">
              <div className="grid gap-8 lg:grid-cols-2 lg:gap-16 items-center">
                <div className="flex flex-col justify-center space-y-4 text-center lg:text-left">
                  <h1 className="font-serif text-4xl font-bold tracking-tight text-foreground sm:text-5xl md:text-6xl">
                    Crea Mockups Profesionales en Segundos
                  </h1>
                  <p className="max-w-[600px] text-muted-foreground md:text-lg mx-auto lg:mx-0">
                    La herramienta definitiva para vendedores de Print on Demand. Acelera tu flujo de trabajo, crea
                    mockups de alta calidad y aumenta tus ventas.
                  </p>
                  <div className="hidden lg:flex flex-col gap-4 sm:flex-row sm:justify-center lg:justify-start pt-4">
                    <a href={checkoutUrl} target="_blank" rel="noopener noreferrer">
                      <Button
                        size="lg"
                        className="h-14 text-lg font-bold bg-primary text-primary-foreground hover:bg-primary/90"
                      >
                        ¡Lo Quiero Ahora!
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </a>
                  </div>
                </div>
                <div className="flex items-center justify-center">
                  <AnimatedHeroImage />
                </div>
              </div>
            </div>
          </section>

          {/* Benefits Section */}
          <section className="w-full bg-secondary py-12 md:py-20">
            <div className="container px-4 md:px-6">
              <div className="mx-auto max-w-3xl text-center">
                <h2 className="font-serif text-3xl font-bold tracking-tight sm:text-4xl">
                  Transforma Horas de Trabajo en Segundos
                </h2>
                <p className="mt-4 text-muted-foreground md:text-lg">
                  Deja de perder tiempo. Con TurboMockups, tu proceso de creación de mockups para tu tienda online será
                  más rápido que nunca.
                </p>
              </div>
              <div className="mx-auto mt-12 grid max-w-5xl gap-6 md:grid-cols-2 lg:grid-cols-3">
                {[
                  {
                    icon: Layers3,
                    title: "Mockups Masivos",
                    desc: "Crea cientos de mockups para tus diseños con un solo clic.",
                  },
                  {
                    icon: Check,
                    title: "Fácil de Usar",
                    desc: "No necesitas programas complicados. Todo funciona dentro de la plataforma Canva Pro.",
                  },
                  {
                    icon: ArrowRight,
                    title: "Acceso de por Vida",
                    desc: "Un único pago te da acceso para siempre, incluidas las actualizaciones.",
                  },
                  {
                    icon: Clapperboard,
                    title: "Tutorial Paso a Paso",
                    desc: "Te guío en video para que uses la herramienta en menos de 5 minutos.",
                  },
                  {
                    icon: Sparkles,
                    title: "Tips Exclusivos",
                    desc: "Tips para crear mockups que realmente venden y destacan de la competencia.",
                  },
                  {
                    icon: Palette,
                    title: "Disponible para:",
                    desc: "Camisetas, Tazas y Mantas. Incluye plantillas separadas para cada producto. ¡Y se vienen más productos pronto!",
                  },
                ].map((feature) => (
                  <div key={feature.title} className="rounded-xl bg-card p-6 border border-black/5 shadow-lg">
                    <feature.icon className="h-8 w-8 text-primary mb-4" />
                    <h3 className="font-serif text-xl font-bold">{feature.title}</h3>
                    <p className="text-muted-foreground mt-2">{feature.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <MockupShowcase />

          {/* Pricing Section */}
          <section id="oferta" className="w-full bg-secondary py-12 md:py-20">
            <div className="container px-4 md:px-6">
              <div className="mx-auto max-w-md text-center">
                <h2 className="font-serif text-3xl font-bold tracking-tight sm:text-4xl">OFERTA EXCLUSIVA COMUNIDAD</h2>
                <p className="mt-4 text-muted-foreground md:text-lg">
                  Esta es tu única oportunidad para obtener acceso total a un precio que no se repetirá.
                </p>
              </div>
              <div className="mt-8 flex justify-center">
                <Card className="w-full max-w-sm border border-primary/20 bg-card shadow-2xl shadow-primary/10">
                  <CardHeader className="text-center">
                    <Clock className="mx-auto h-8 w-8 text-primary mb-2" />
                    <CardTitle className="font-serif text-xl text-primary">La oferta termina en:</CardTitle>
                    <CountdownTimer targetDate={launchDate} />
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-baseline justify-center text-center gap-2 sm:gap-4">
                      <span className="text-5xl sm:text-6xl font-bold text-primary">$39</span>
                      <span className="text-lg text-muted-foreground">USD</span>
                    </div>
                    <div className="flex items-center justify-center gap-2 mt-2">
                      <span className="text-lg text-muted-foreground line-through">$119</span>
                      <span className="text-sm text-muted-foreground">precio regular</span>
                    </div>
                    <p className="mt-2 text-sm text-center text-muted-foreground">Pago único. Acceso de por vida.</p>
                    <a href={checkoutUrl} target="_blank" rel="noopener noreferrer">
                      <Button
                        size="lg"
                        className="mt-6 w-full h-14 text-lg font-bold bg-primary text-primary-foreground hover:bg-primary/90"
                      >
                        ¡Lo Quiero Ahora!
                        <ArrowRight className="ml-2 h-5 w-5" />
                      </Button>
                    </a>
                  </CardContent>
                </Card>
              </div>
            </div>
          </section>

          <TestimonialsSection />

          {/* FAQ Section */}
          <section className="w-full py-12 md:py-20">
            <div className="container mx-auto max-w-3xl px-4 md:px-6">
              <div className="text-center">
                <h2 className="font-serif text-3xl font-bold tracking-tight sm:text-4xl">Preguntas Frecuentes</h2>
              </div>
              <div className="mt-12">
                <Accordion type="single" collapsible className="w-full">
                  {faqData.map((faq, i) => (
                    <AccordionItem key={i} value={`item-${i + 1}`}>
                      <AccordionTrigger className="font-serif text-base sm:text-lg text-left hover:text-primary">
                        {faq.question}
                      </AccordionTrigger>
                      <AccordionContent className="text-muted-foreground">{faq.answer}</AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>
            </div>
          </section>
        </main>

        {/* Footer */}
        <footer className="w-full border-t border-primary/10 py-8 bg-secondary">
          <div className="container text-center text-sm text-muted-foreground space-y-1">
            <p>© 2025 Allison Ramirez. Todos los derechos reservados.</p>
            <p>
              Soporte:{" "}
              <a href="mailto:help.allisonramirez@gmail.com" className="text-primary hover:underline">
                help.allisonramirez@gmail.com
              </a>
            </p>
            <p>Requiere una cuenta en una plataforma de diseño compatible.</p>
          </div>
        </footer>
      </div>
      <StickyCTA />
    </>
  )
}
