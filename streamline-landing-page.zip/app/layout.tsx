import type React from "react"
import type { Metadata } from "next"
import { Inter, Lora } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" })
const lora = Lora({ subsets: ["latin"], weight: ["400", "700"], variable: "--font-lora" })

export const metadata: Metadata = {
  title: "TurboMockups: Crea Mockups Profesionales en Canva en Segundos",
  description:
    "TurboMockups es la herramienta perfecta para vendedores de Print on Demand. Crea mockups en segundos y acelera tus ventas. Oferta de lanzamiento: $19.",
  keywords: [
    "mockups para tienda online",
    "mockups para Print on Demand",
    "crear mockups rápido",
    "TurboMockups herramienta",
    "mockups profesionales",
  ],
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="es">
      <body
        className={`${inter.variable} ${lora.variable} font-sans bg-background text-foreground antialiased relative overflow-x-hidden`}
      >
        <div className="absolute top-0 left-0 -z-10 h-full w-full bg-[radial-gradient(#443e391f_1px,transparent_1px)] [background-size:16px_16px]"></div>
        {children}
      </body>
    </html>
  )
}
