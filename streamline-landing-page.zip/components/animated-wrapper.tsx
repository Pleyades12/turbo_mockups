"use client"

import type React from "react"

import { motion, type Variants } from "framer-motion"

interface AnimatedWrapperProps {
  children: React.ReactNode
  className?: string
  variants?: Variants
  initial?: string
  whileInView?: string
  viewport?: object
}

const defaultVariants: Variants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.6,
      ease: "easeOut",
      staggerChildren: 0.2,
    },
  },
}

export function AnimatedWrapper({
  children,
  className,
  variants = defaultVariants,
  initial = "hidden",
  whileInView = "visible",
  viewport = { once: true, amount: 0.3 },
}: AnimatedWrapperProps) {
  return (
    <motion.div
      className={className}
      variants={variants}
      initial={initial}
      whileInView={whileInView}
      viewport={viewport}
    >
      {children}
    </motion.div>
  )
}

export const itemVariants: Variants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.5,
      ease: "easeOut",
    },
  },
}
