"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

const MotionButton = motion(Button)

export function StickyCTA() {
  const checkoutUrl = "https://www.allisonramirezb.com/offers/krN7a4RB/checkout"

  return (
    <motion.div
      initial={{ y: "100%" }}
      animate={{ y: "0%" }}
      transition={{ duration: 0.5, ease: "easeOut", delay: 2 }}
      className="fixed bottom-0 left-0 right-0 z-50"
    >
      <div className="container mx-auto p-4">
        <a href={checkoutUrl} target="_blank" rel="noopener noreferrer" className="block">
          <div className="flex items-center justify-between gap-4 rounded-lg bg-secondary/80 p-3 backdrop-blur-lg border border-primary/20 shadow-lg">
            <div className="flex flex-col">
              <span className="text-sm font-bold text-primary">OFERTA EXCLUSIVA COMUNIDAD</span>
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-primary">$39 USD</span>
                <span className="text-xs text-muted-foreground line-through">$119</span>
              </div>
            </div>
            <MotionButton
              size="sm"
              className="font-bold bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_15px_rgba(161,128,87,0.4)] pointer-events-none"
              animate={{
                scale: [1, 1.05, 1],
              }}
              transition={{
                duration: 1.5,
                repeat: Number.POSITIVE_INFINITY,
                ease: "easeInOut",
              }}
            >
              ¡Lo Quiero!
              <ArrowRight className="ml-1.5 h-4 w-4" />
            </MotionButton>
          </div>
        </a>
      </div>
    </motion.div>
  )
}
