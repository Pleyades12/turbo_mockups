"use client"

import Image from "next/image"
import { motion, useMotionValue, useTransform } from "framer-motion"
import type React from "react"

export function AnimatedHeroImage() {
  const x = useMotionValue(0)
  const y = useMotionValue(0)

  const rotateX = useTransform(y, [-100, 100], [10, -10])
  const rotateY = useTransform(x, [-100, 100], [-10, 10])

  const handleMouseMove = (event: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
    const rect = event.currentTarget.getBoundingClientRect()
    const width = rect.width
    const height = rect.height
    const mouseX = event.clientX - (rect.left + width / 2)
    const mouseY = event.clientY - (rect.top + height / 2)
    x.set(mouseX)
    y.set(mouseY)
  }

  const handleMouseLeave = () => {
    x.set(0)
    y.set(0)
  }

  return (
    <motion.div
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{
        transformStyle: "preserve-3d",
        perspective: "1000px",
      }}
      className="w-full h-full flex items-center justify-center"
    >
      <motion.div
        style={{
          rotateX,
          rotateY,
          transformStyle: "preserve-3d",
        }}
        animate={{
          y: [0, -12, 0],
        }}
        transition={{
          duration: 6,
          ease: "easeInOut",
          repeat: Number.POSITIVE_INFINITY,
        }}
        className="relative"
      >
        <motion.div
          style={{
            transform: "translateZ(20px)",
          }}
          className="absolute -inset-4 bg-primary/10 rounded-2xl blur-xl"
        />
        <Image
          src="/turbomockups-hero-new.png"
          width={550}
          height={550}
          alt="Demostración del curso y la herramienta TurboMockups en diferentes dispositivos"
          className="relative rounded-xl object-contain shadow-2xl shadow-primary/20"
          style={{
            transform: "translateZ(40px)",
          }}
          priority
        />
      </motion.div>
    </motion.div>
  )
}
