import Image from "next/image"

const showcaseImages = [
  {
    src: "/mockup-showcase-shirts.png",
    alt: "Ejemplos de mockups de camisetas creados con TurboMockups",
  },
  {
    src: "/mockup-showcase-mugs.png",
    alt: "Ejemplos de mockups de tazas creados con TurboMockups",
  },
  {
    src: "/mockup-showcase-blankets.png",
    alt: "Ejemplos de mockups de mantas creados con TurboMockups",
  },
]

export function MockupShowcase() {
  return (
    <section className="w-full py-12 md:py-20">
      <div className="container px-4 md:px-6">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="font-serif text-3xl font-bold tracking-tight sm:text-4xl">
            Tu Diseño en Cientos de Mockups, al Instante
          </h2>
          <p className="mt-4 text-muted-foreground md:text-lg">
            Visualiza cómo tus creaciones cobran vida en una variedad de productos. Un solo diseño, infinitas
            posibilidades.
          </p>
        </div>
        <div className="mt-12 grid gap-8">
          {showcaseImages.map((image, index) => (
            <div key={index} className="overflow-hidden rounded-xl border border-primary/10 bg-card shadow-lg">
              <Image
                src={image.src || "/placeholder.svg"}
                alt={image.alt}
                width={1200}
                height={600}
                className="w-full h-auto object-cover"
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
