import Image from "next/image"

const testimonials = [
  {
    src: "/testimonials/testimonial-laura-velandia.jpg",
    alt: "Testimonio de Laura Velandia sobre TurboMockups",
  },
  {
    src: "/testimonials/testimonial-oli-n.jpg",
    alt: "Testimonio de Oli_N sobre TurboMockups",
  },
  {
    src: "/testimonials/testimonial-erika-ramirez.jpg",
    alt: "Testimonio de Erika Ramirez sobre TurboMockups",
  },
  {
    src: "/testimonials/testimonial-maria-moreno.jpg",
    alt: "Testimonio de Maria Moreno sobre TurboMockups",
  },
  {
    src: "/testimonials/testimonial-maria-del-carmen.jpg",
    alt: "Testimonio de María del Carmen Vera sobre TurboMockups",
  },
  {
    src: "/testimonials/testimonial-milena-pinilla.jpg",
    alt: "Testimonio de Milena Pinilla sobre TurboMockups",
  },
  {
    src: "/testimonials/testimonial-manuel-ramirez.jpg",
    alt: "Testimonio de Manuel Ramirez sobre TurboMockups",
  },
]

export function TestimonialsSection() {
  return (
    <section className="w-full py-12 md:py-20 bg-secondary">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="font-serif text-3xl font-bold tracking-tight sm:text-4xl">Lo que dicen nuestros usuarios</h2>
          <p className="mt-4 text-muted-foreground md:text-lg">
            Personas como tú ya están ahorrando horas de trabajo y potenciando sus tiendas.
          </p>
        </div>
        <div className="mt-12">
          <div className="columns-1 sm:columns-2 lg:columns-3 xl:columns-4 gap-6 space-y-6">
            {testimonials.map((testimonial, i) => (
              <div key={i} className="break-inside-avoid-column">
                <Image
                  src={testimonial.src || "/placeholder.svg"}
                  alt={testimonial.alt}
                  width={400}
                  height={300}
                  className="w-full h-auto rounded-xl shadow-lg border border-primary/10"
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
